package com.example

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.databinding.FragmentMaruzaBinding

class MaruzaFragment : Fragment(), OnSectionClick {
    private lateinit var _binding: FragmentMaruzaBinding
    private val mBinding: FragmentMaruzaBinding get() = _binding
    private val sectionList = arrayListOf<Section>()

    private lateinit var adapter: SectionAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {


        _binding = FragmentMaruzaBinding.inflate(layoutInflater, container, false)
        return mBinding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initViews()

        adapter = SectionAdapter(sectionList, this)

        mBinding.rvSection.layoutManager = GridLayoutManager(requireContext(), 2)
        mBinding.rvSection.adapter = adapter
    }

    private fun initViews() {
        sectionList.add(Section("1-maruza"))
        sectionList.add(Section("2-maruza"))
        sectionList.add(Section("3-maruza"))
        sectionList.add(Section("4-maruza"))
        sectionList.add(Section("5-maruza"))
        sectionList.add(Section("6-maruza"))
        sectionList.add(Section("7-maruza"))
        sectionList.add(Section("8-maruza"))
        sectionList.add(Section("9-maruza"))
        sectionList.add(Section("10-maruza"))
        sectionList.add(Section("11-maruza"))
        sectionList.add(Section("12-maruza"))
        sectionList.add(Section("13-maruza"))
        sectionList.add(Section("14-maruza"))
        sectionList.add(Section("15-maruza"))
    }

    override fun openSection() {
        Log.d("XXXXX", "openSection: ")
        requireActivity().supportFragmentManager.beginTransaction().replace(R.id.fragment_container ,
            SectionFragment()
        ).addToBackStack(null).commit()
    }


}