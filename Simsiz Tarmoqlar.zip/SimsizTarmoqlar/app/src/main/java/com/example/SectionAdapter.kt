package com.example

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.databinding.ItemCardViewBinding

class SectionAdapter(
    private val sectionList: ArrayList<Section>,
    private val onSectionClick: OnSectionClick
) : RecyclerView.Adapter<VH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding =
            ItemCardViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding, onSectionClick)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(sectionList[position])
    }

    override fun getItemCount(): Int {
        return sectionList.size
    }
}

class VH(private val mBinding: ItemCardViewBinding, private val onSectionClick: OnSectionClick) :
    RecyclerView.ViewHolder(mBinding.root) {
    fun bind(item: Section) {
        mBinding.tvSec.text = item.name
        Log.d("XXXXX", "bind: ${item.name} ")
        mBinding.root.setOnClickListener {
            Log.d("XXXXX", "bind: ")
            onSectionClick.openSection() }
    }

}