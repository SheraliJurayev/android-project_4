package com.example

data class Section(
    val name: String
)
