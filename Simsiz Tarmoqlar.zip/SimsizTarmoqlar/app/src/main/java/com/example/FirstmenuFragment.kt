package com.example

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.databinding.FragmentFirstmenuBinding


class FirstmenuFragment : Fragment() {
    private lateinit var _binding: FragmentFirstmenuBinding
    private val mBinding: FragmentFirstmenuBinding get() = _binding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstmenuBinding.inflate(layoutInflater, container, false)
        return mBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mBinding.cvMaruza.setOnClickListener {

            val fragmentMaruza = MaruzaFragment()
            loadFragment(fragmentMaruza)
        }
        mBinding.cvLaboratoriya.setOnClickListener {
            // TODO Oxirigacha etkizing
            //val fragmentLabaatoriya = LabaratoriyaFragment()
            //loadFragment(fragmentLabaatoriya)
        }
    }

    private fun loadFragment(fragment: Fragment) {
        val fragmentManager = requireActivity().supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragment_container, fragment)
        fragmentTransaction.addToBackStack(fragment::javaClass.name).commit()
    }


}
