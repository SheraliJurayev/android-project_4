package com.example

interface OnSectionClick {
    fun openSection()
}